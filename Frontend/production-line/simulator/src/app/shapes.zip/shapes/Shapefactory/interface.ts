export interface Shape {
  structure: any;
  get(): any;
}
