import { Layer } from "konva/lib/Layer";
export class View {
  staticLayer!: Layer;
  dynamicLayer!: Layer;
  shapes!: any[];
}
